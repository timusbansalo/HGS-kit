﻿****************************************************************************************************************************************************************************************************************************************************************************
Intel(R) Power And Thermal Analysis Tool
VERSION 02.01.1002 README
Nov 24,2022
***************************************************************************************************************************************************************************************************************************************************************************************************************************************************>

README Contents
============================================
1.  Introduction
2.  Installation Instructions
3.  System Requirements
3.a Operating systems
3.b Browsers
3.c Platforms supported
4.  Release Notes
5.  Known Issues and Bug Reporting
6.  Support
7.  License Agreement
8.  3rd party software
9.  Download Link
10. Latest Version
****************************************************************************************************************************************************************************************************************************************************************************

1.  Introduction
============================================
This README file contains release notes for the Intel® Power And Thermal Analysis Tool, describing changes, any problems or issues that were known at the time of shipment.  
Please read PTAT Help File for all the features. 
 
2.  Installation Instructions
============================================
Please refer to Intel (R) Power And Thermal Analysis Tool Help.pdf for installation instructions.

3.  System Requirements
============================================
3.a Operating system
   The Intel® Power And Thermal Analysis Tool supports the following operating systems:

   Microsoft® Windows 10 RS2 Desktop and Above  64 Bit
   Microsoft® Windows 11 RS2 Desktop and Above  64 Bit
   Ubuntu 
   Fedora
   SUSE
   CentOS
   YoctoOS

3.b Browsers  
    The tool supports the following Browsers:
	
    Edge
    Chrome

3.c Platforms supported
   The utility  supports  the following microprocessors:
   
   Client Platforms:   
   Intel® Core Processor Line Code name RapterLake Processor
   Intel® Core Processor Line Code name AlderLake Processor
   Intel® Core Processor Line Code name MeteorLake Processor (Stress is not yet enabled)
   Discrete Graphics (DG1/DG2/ATS-M)
   Discrete Visual Processing Unit (dVPU)
      
4.Release Notes
============================================
Release 02.01.1002
Windows:
1. Multi Phidget Support Enabled.
2. TigerLake support added (PV added in the dependencies, not integrated, updated the help document with the same)
3. CPU ALL option added for Scripts to run workloads.
4. RPL Power Virus updated (IA workloads) for RPL HX, P
5. Static Parameters will be logged in by default to the same PTAT log file. User can enable static data logging from UI Settings
6. PTAT Workspace option has been enabled
7. Turbo Test Workloads are enabled for RPL to validate the turbo frequency behavior of CPU
8. Bug fixes reported in 02.01.1001


Release 02.01.1001
Windows:
1. RPL-S, RPL-P, RPL-SBGA (HX) Tuned workloads enabled (only with Turbo ON), Turbo OFF will not have any effect while running the workloads
   Please note that these workloads will set PL1 and PL2 parameters while running workloads and will set it back to original when stress is stopped.
2. RPL-S, RPL-SBGA (HX)-Thermal workloads enabled (please check Help document for more details)
3. IA P state feature enabled 
4. Bugfixes reported from previous release
5. IA and GT Clip Reason reporting issue fix
6. ze_loader.dll issue resolved
7. graph issue with time scale has been resolved
8. CPU-Info issue resolved
9. MMIO PL reset issue resolved.

Linux:
1. First release with PTAT 2.x supporting Linux
2. RPL-S and RPL-P tuned workloads enabled
3. Supported platforms - ADL, RPL
4. DG support enabled 
5. Supported Linux OS : Ubuntu, CentOS, Fedora, SUSE, Yocto OS

Release 02.00.1002
1. Resolved the frequency drop issue with PTAT close
2. ADL-PS enablement along with IA100% and thermal workloads
3. IPC issue fix for ADL/RPL with big and small cores combination
4. Fixed the crash issue with graphs
5. Enabled thermal workload for ADL-SBGA and ADL-N
6. ATS-M Support added for Windows build (Validated on DG systems, partially validated on ATS-M system)
7. RPL-S IA tuned workloads enabled


Release 2.0.0001
1. Added support for Alder Lake Processors
2. Added CPU workloads for ADL-S/P/M and Thermal workloads from PTAT 1.x
3. Added CPU workloads for ADL-N (100% only - due to small TDP of the system, tuning not possible)
4. Addd CPU workloads for ADL-SBGA
5. Added support for dVPU (monitor and control)
6. Fixed bugfixes raised from PTAT 1.x and 2.00.0000

Release 2.00.0000
First Release of converged PTAT tool with improved architecture to support both Client and Server platforms


5.  Known Issues and Bug Reporting
============================================
To report a bug on this utility, please submit the bug report to your Intel Field Representative.

1. If application closes unexpectedly, all controls may not be reset.
2. Tool is launched on system's default browser. If the default browser is not working then Tool may also not launch. In this case copy tool's link and paste it in any edge/chrome browser to launch.
3. PTAT will become slow when more that 40 graph parameters are added for live graph. This issue will be fixed in next release.
4. If any feature is not supported from DPTF on a particular system, PTAT will show ‘X’ to show it is not supported for that device.
5. PTAT will show Integrated power as 0 if the Intel Graphics driver is not present. 
6. Below components are not yet supported and will be supported in future releases
   a. Phidget
   b. PTAT Solvers/Live analysis  
   
7. Known issues
   a. If PTAT 1.x and PTAT 2.x are installed simultaneously on the same system, it can result in misbehavior of the tool. Please uninstall any older version PTAT installed on the system, before installing PTAT 2.x.
   b. Secure boot needs to be disabled due to test signed driver being used. Please refer section Disabling or Enabling test signing for driver in help document.
   c. Parameters read from PECI and BIOS mailbox may result in Invalid reads. Please check section Known issues that cannot be fixed.
   d. CPU workloads are tuned wrt to the specific SKUs available with the team, with different SKUs, the workload behaviors may change slightly. Please try with different combinations of workload to achieve TDP, else report the issue to Intel representative.
   e. Older Scripts (xml) will not work with PTAT 2.x. Please create equivalent json script files. Please refer to section updated script files from xml to json in help document
   f. System is hanging when In Graph Tab, Online graph parameters added and removed.
   g. AVX Workloads show slight variation when run from PTAT UI for RPL-HX and RPL-P. Recommendation is to use Commandline to validate system behavior with PTAT Scrit to run stress

Points to be noted
--------------------------------------------
1. Gfx workload will run only if Intel Gfx driver installed on Windows. 
2. PTAT shall disable PState features if Speed Shift Technology (HW-PStates) enabled in BIOS as PTAT can not control PStates. This  is expected behavior. 

6. Support 
============================================
Please get in touch with Customer Support representative for any additional queries

7. License Agreement:
============================================
This ReadMe file as well as the software described in it is furnished under license and may only be used or copied in accordance with the terms of the license. The information in this manual is furnished for informational use only, is subject to change without notice, and should not be construed as a commitment by Intel Corporation. Intel Corporation assumes no responsibility or liability for any errors or inaccuracies that may appear in this document or any software that may be provided in association with this document.

Except as permitted by such license, no part of this document may be reproduced, stored in a retrieval system, or transmitted in any form or by any means without the express written consent of Intel Corporation. 
Information in this document is provided in connection with Intel products. No license, expressed or implied otherwise, to any intellectual property rights is granted by this document. Except as provided in Intel's Terms and Conditions of Sale for such products, Intel assumes no liability whatsoever, and Intel disclaims any express or implied warranty, relating to sale and/or use of Intel products including liability or warranties relating to fitness for a particular purpose, merchantability, or infringement of any patent, copyright or other intellectual property right. Intel products are not intended for use in medical, lifesaving, or life sustaining applications. Intel may make changes to specifications and product descriptions at any time, without notice.
Copyright (C) 2022 Intel Corporation. All rights reserved.

Intel is a trademark or registered trademark of Intel Corporation or its subsidiaries in the registered trademark of Intel Corporation or its subsidiaries in the United States and other countries.

8. 3rd party software:
============================================
1. Libxml2 -Open Source(MIT license)
2. Zlib - Zlib license
3. libSQLite3 - Public Domain
4. Iconv-lite - Open Source(MIT License)
5. Pandas library - BSD 3-clause "New" or "Revised" License
6. Microsoft DirectX-Graphics-Samples for Windows 10 - Open Source(MIT License)
7. Font Awesome - CC-BY-4.0, MIT License
8. Popper js - MIT License
9. angular2-websocket - MIT License
10. jQuery - MIT License
11. jQuery UI - MIT License
12. jquery-ui-dist - MIT License
13. ngx-spinner - MIT License
14. RxJS - Apache-2.0
15. Zone.js - MIT License
16. Bootstrap - MIT License
17. angular-notifier - MIT License
18. canvas JS - Commercial License 
19. web-animations-js - Apache-2.0
20. classlist.js - Unlicense
21. Angular Framework - MIT License
22. tslib - Apache-2.0
23. FileSaver.js - MIT License
24. ngx-filesaver - MIT License
25. parse5 - MIT License
26. bluebird - MIT License
27. Hammer.js - MIT License
28. jquery-shapeshift - MIT License
29. Visual C++ Redistributable for Visual Studio - Microsoft Visual Studio 2017 Enterprise, Professional, Test Professional and Trial Edition License
30. OneApi Library for DG - Intel
31. glibc -  GNU Lesser General Public License

* Third-party brands and names are the property of the respective owners.
* Note : For detailed license information of 3rd party softwares used, please refer ThirdPartyLicense.txt

9. Download Link
============================================
External customers can download the tool from link below:
https://www.intel.com/content/www/us/en/secure/design/confidential/software-kits/kit-details.html?kitId=637737

10. Latest Version
============================================
Latest version of PTAT : 02.01.1002 

**********************************************************************************************************************************************
